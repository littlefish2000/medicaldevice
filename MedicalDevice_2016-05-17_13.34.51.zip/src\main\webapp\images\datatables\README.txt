License
===========

"book_add.png", "book_delete.png","page_white_acroba.png", "page_white_text.png" and "page_excel.png" are licensed 
under Creative Commons Attribution 2.5 License by 
Mark James (http://www.famfamfam.com/about) from famfamfam.com.


