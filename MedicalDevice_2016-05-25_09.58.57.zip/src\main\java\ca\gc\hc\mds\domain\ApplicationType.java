package ca.gc.hc.mds.domain;

public enum ApplicationType {

    AMENDMENT
}
