package ca.gc.hc.mds.domain;
import org.springframework.roo.addon.dod.RooDataOnDemand;

@RooDataOnDemand(entity = Application.class)
public class ApplicationDataOnDemand {
}
